package Events;

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Commandlist extends ListenerAdapter {

    public void onGuildMessageReceived(GuildMessageReceivedEvent EventIvan){

        String messegeSent = EventIvan.getMessage().getContentRaw();
        if(messegeSent.equalsIgnoreCase("!Dakota")){
            EventIvan.getChannel().sendMessage("Oh dakota you sexy beast what should i do for you tonight master ").queue();
        }

        String messegesSent = EventIvan.getMessage().getContentRaw();
        if(messegesSent.equalsIgnoreCase("!commands")){
            EventIvan.getChannel().sendMessage("-Commands-\n" +

                    "!Dakota \n" +
                    "!time \n" +
                    "!todo \n" +
                    "!SoundDep \n "+
                    "!ArtDep"
                    ).queue();
        }
    }

}