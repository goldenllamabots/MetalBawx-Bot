package Events;

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class SoundDep extends ListenerAdapter {

    public void onGuildMessageReceived(GuildMessageReceivedEvent EventSound){

        String message3Sent = EventSound.getMessage().getContentRaw();
        if(message3Sent.equalsIgnoreCase("!SoundDep")){

            EventSound.getChannel().sendMessage("-Sound Department- \n" +
                            "Sound Department Lead (Aidwell)" + "\n"+
                            "\n {Voice Actors} " + "\n"+
                            " -Kavin \n -Water \n -Slyzah \n -Omes \n -klink \n -Izekial \n -[Vi] Jarl Torin Steel \n -Warboss \n -GrimTitan \n -KiddingEmperor \n -Kogenta Skul \n "+
                            " \n {SoundTrack Artist}" + "\n"+
                            "  -edwindizer \n -Kavin \n" +
                            " \n {Sount FX} \n"+
                            " -adamlwood \n  -Nag \n -Kavin \n"
                              ).queue();

        }

    }

}