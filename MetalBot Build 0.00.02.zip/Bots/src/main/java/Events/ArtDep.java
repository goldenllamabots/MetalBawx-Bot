package Events;

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class ArtDep extends ListenerAdapter {

    public void onGuildMessageReceived(GuildMessageReceivedEvent EventArt){

        String message3Sent = EventArt.getMessage().getContentRaw();
        if(message3Sent.equalsIgnoreCase("!ArtDep")){
            EventArt.getChannel().sendMessage("(ArtDepartment) \n" +
                            "Art Department Leads (Marian: Concept Art) (BossJesse: 3d modeler)" + "\n"+

                            " {3d Modelers}" + "\n"+
                            " -Derrick \n -slowdom \n -Splitmoon \n -CrazyHamster\n " + "\n"+

                            " {Concept Artist}" + "\n"+
                            " -LookItsaWolf" + "\n -CrazyHamster\n" + "\n" +

                            " {Level Designers}" + "\n" +
                            " -DeGoldenLLama \n" +"\n" +

                            " {Environment artist} \n" +
                            " -LookItsawolf \n " + "\n" +

                            " {Texture Artist} \n" +
                            " -LookItsaWolf \n -CrazyHamster \n"

                    +"\nTHIS LIST IS BEING UPDATED! \n NOT IN FINAL FORM!"

            ).queue();


        }

    }

}
