package Events;

import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Todolist extends ListenerAdapter {

    public void onGuildMessageReceived(GuildMessageReceivedEvent EventTodo){


        String messege1Sent = EventTodo.getMessage().getContentRaw();
        if(messege1Sent.equalsIgnoreCase("!todo")){
            EventTodo.getChannel().sendMessage(" We are nearing the stage where we can take a breather with the GDD so we want to start focusing on the second phase of the prototype.\n " +
                    "For this phase we need \n" +
                    " - a working vehicle, \n" +
                    " - two character models to pick, \n" +
                    " - more animations, \n" +
                    " - textures, \n" +
                    " - the UI, \n" +
                    " - Sounds, \n" +
                    " - Spawn mechanics, \n" +
                    " - Voice lines,\n" +
                    " - Special Effects (laser gun shots, weather and the such) \n" +
                    " - a win objective. \n" +
                    "Please reach out to your team leads if you havent already about this so that way we can focus in on reaching our goal. \n" +
                    "Lets try to make this happen within the next 2 months guys! ").queue();


        }

    }

}
