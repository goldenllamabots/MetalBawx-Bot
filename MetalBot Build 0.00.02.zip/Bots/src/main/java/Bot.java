import Events.*;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;

public class Bot {

    public static void main (String args []) throws Exception{

        JDA jda = new JDABuilder( "NTk4NjI5MzcxNTk0NDA3OTc5.XSZjlA.MSFmeE3JysDwUvxKyvPIoRsCvA0").build();

        jda.addEventListener(new Commandlist());
        jda.addEventListener(new Todolist());
        jda.addEventListener(new Time());
        jda.addEventListener(new SoundDep());
        jda.addEventListener(new ArtDep());

    }

}
